import type { NextConfig } from "next";
import { readFileSync } from "node:fs";

const configuredDistDir = process.env.NETWORKIS_NEXT_DIST_DIR;
let frontendBuildId = "development";
let frontendPatchId = "";
if (process.env.NODE_ENV === "production") {
  try {
    const manifest = JSON.parse(readFileSync(new URL("./public/build-info.json", import.meta.url), "utf8"));
    frontendBuildId = manifest.build_id;
    frontendPatchId = manifest.frontend_patch_id ?? "";
  } catch { /* A local build can run without a release manifest. */ }
}

const nextConfig: NextConfig = {
  env: { NEXT_PUBLIC_NETWORKIS_BUILD_ID: frontendBuildId, NEXT_PUBLIC_NETWORKIS_FRONTEND_PATCH_ID: frontendPatchId },
  allowedDevOrigins: ["127.0.0.1", "localhost"],
  // Large, atomic engineering applies share the bounded agent request budget.
  // Next's 30-second default can otherwise discard an already committed reply.
  experimental: { proxyTimeout: 600_000 },
  distDir: configuredDistDir ?? ".next-networkis",
  turbopack: {
    root: process.cwd(),
  },
  async rewrites() {
    // In production sind die "services"-Rewrites aus der Wurzel-vercel.json
    // zuständig (/api/* -> backend-Service) - Requests für /api/* erreichen
    // diesen Next.js-Dienst dort gar nicht erst. Im lokalen `next dev`
    // (ohne `vercel dev`-Orchestrierung) fehlt dieses Routing jedoch, daher
    // proxyen wir /api/* hier zusätzlich auf das lokal laufende Flask-Backend.
    const backendApiUrl = process.env.SIMULATOR_BACKEND_API_URL;
    if (!backendApiUrl) return [];
    return [
      {
        source: "/api/:path((?!agent).*)",
        destination: `${backendApiUrl}/:path*`,
      },
    ];
  },
};

export default nextConfig;
