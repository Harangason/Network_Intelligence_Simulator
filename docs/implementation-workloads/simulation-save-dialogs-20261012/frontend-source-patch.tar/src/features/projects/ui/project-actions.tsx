"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { clearEngineeringAgentHistory } from "@/features/agent/lib/agent-chat-history";
import { openProjectBundleFromFile, saveProjectBundleToFile } from "@/features/projects/lib/project-file";
import { createNetworkProjectId } from "@/features/projects/lib/project-ids";
import { clearWorkflowApiCaches, exportProjectBundle, getWorkflowSummary, importProjectBundle, resetProjectWorkspace } from "@/features/workflow/lib/workflow-api";
import { normalizeProjectId, readUserSettings, withProjectParam, writeUserSettings } from "@/features/settings/lib/user-settings";
import {
  ENGINEERING_AGENT_PENDING_TASK_KEY,
  ENGINEERING_AGENT_PENDING_WIZARD_KEY,
  ENGINEERING_AGENT_WIZARD_SESSION_KEY,
} from "@/features/agent/lib/agent-task-events";
import { notifyWorkflowChanged } from "../../workflow/ui/workflow-header";
import { SaveDialog } from "./save-dialog";

type ProjectActionsProps = {
  className?: string;
  showMessage?: boolean;
};

export function ProjectActions({ className = "project-actions", showMessage = true }: ProjectActionsProps) {
  const router = useRouter();
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [clearDialogOpen, setClearDialogOpen] = useState(false);
  const [projectId, setProjectId] = useState("");
  const [saveNewProject, setSaveNewProject] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [busy, setBusy] = useState<"clear" | "save" | "open" | "">("");
  const [message, setMessage] = useState("");

  function setActiveProject(nextProjectId: string) {
    writeUserSettings({ ...readUserSettings(), activeProject: normalizeProjectId(nextProjectId) });
    notifyWorkflowChanged();
  }

  function createProjectId() {
    return createNetworkProjectId();
  }

  function clearBrowserProjectState(projectIds: string[]) {
    clearWorkflowApiCaches();
    window.sessionStorage.removeItem(ENGINEERING_AGENT_PENDING_TASK_KEY);
    window.sessionStorage.removeItem(ENGINEERING_AGENT_PENDING_WIZARD_KEY);
    window.sessionStorage.removeItem(ENGINEERING_AGENT_WIZARD_SESSION_KEY);
    window.sessionStorage.removeItem("networkis:forced-agent-questionnaire");
    window.sessionStorage.removeItem("networkis:handled-agent-questionnaires");
    window.sessionStorage.removeItem("networkis:agent-project-brief");
    window.sessionStorage.removeItem("networkis:pending-agent-new-project");
    for (const id of projectIds) {
      window.localStorage.removeItem(`networkis:engineering-agent-wizard:${id}`);
    }
  }

  async function saveProject(targetProjectId?: string, forceChoose = false) {
    setBusy("save");
    setMessage("");
    setSaveError("");
    try {
      const target = targetProjectId ? normalizeProjectId(targetProjectId) : undefined;
      const bundle = await exportProjectBundle(target);
      const saved = await saveProjectBundleToFile(bundle, { forceChoose });
      setActiveProject(bundle.project_id);
      setSaveDialogOpen(false);
      setMessage(`Gespeichert: ${saved.fileName}`);
    } catch (caught) {
      if ((caught as { name?: string }).name !== "AbortError") {
        const detail = caught instanceof Error ? caught.message : "Projekt konnte nicht gespeichert werden.";
        setMessage(detail);
        setSaveError(detail);
      }
    } finally {
      setBusy("");
    }
  }

  function handleSave() {
    const current = readUserSettings().activeProject;
    setSaveNewProject(current === "default");
    setProjectId(current === "default" ? `network-project-${new Date().toISOString().slice(0, 10)}` : current);
    setSaveError("");
    setMessage("");
    setSaveDialogOpen(true);
  }

  async function handleClear() {
    setBusy("clear");
    setMessage("");
    try {
      const current = readUserSettings().activeProject;
      const nextProjectId = createProjectId();
      await resetProjectWorkspace(current);
      await clearEngineeringAgentHistory(current);
      await clearEngineeringAgentHistory(nextProjectId);
      clearBrowserProjectState([current, nextProjectId]);
      setActiveProject(nextProjectId);
      await getWorkflowSummary();
      setClearDialogOpen(false);
      setMessage(`Geleert: ${current} · Neuer Workspace: ${nextProjectId}`);
      window.location.assign(withProjectParam(`${window.location.pathname}${window.location.search}`, nextProjectId));
    } catch (caught) {
      setMessage(caught instanceof Error ? caught.message : "Workspace konnte nicht geleert werden.");
    } finally {
      setBusy("");
    }
  }

  async function handleOpen() {
    setBusy("open");
    setMessage("");
    try {
      const { bundle, fileName } = await openProjectBundleFromFile((status) => setMessage(status.message));
      setMessage(`Importiere ${fileName} in die Engineering-Datenbank ...`);
      const imported = await importProjectBundle(bundle);
      setActiveProject(imported.project_id);
      setMessage(`Geöffnet: ${imported.project_id}`);
      router.push(withProjectParam("/studio", imported.project_id));
    } catch (caught) {
      if ((caught as { name?: string }).name !== "AbortError") {
        setMessage(caught instanceof Error ? caught.message : "Projekt konnte nicht geöffnet werden.");
      }
    } finally {
      setBusy("");
    }
  }

  return (
    <>
      <div className={className}>
        {showMessage && message && <span className="project-file-message" role="status">{message}</span>}
        <button className="topbar-command danger" disabled={Boolean(busy)} onClick={() => setClearDialogOpen(true)} type="button">Clear</button>
        <button className="topbar-command" disabled={Boolean(busy)} onClick={() => void handleSave()} type="button">Speichern</button>
        <button className="topbar-command" disabled={Boolean(busy)} onClick={() => void handleOpen()} type="button">Öffnen</button>
      </div>

      {clearDialogOpen && (
        <div className="project-dialog-backdrop" role="presentation">
          <section aria-labelledby="project-clear-title" aria-modal="true" className="project-dialog" role="dialog">
            <div>
              <p className="eyebrow">Workspace bereinigen</p>
              <h2 id="project-clear-title">Aktives Projekt leeren?</h2>
              <p>
                Das kanonische Modell, Routing, Vorschläge, Analysen, Simulationen und der Workflowstatus
                von <strong>{readUserSettings().activeProject}</strong> werden dauerhaft entfernt.
              </p>
            </div>
            <div className="project-dialog-actions">
              <button autoFocus className="button secondary" disabled={busy === "clear"} onClick={() => setClearDialogOpen(false)} type="button">Abbrechen</button>
              <button className="button danger" disabled={busy === "clear"} onClick={() => void handleClear()} type="button">
                {busy === "clear" ? "Wird geleert ..." : "Workspace leeren"}
              </button>
            </div>
          </section>
        </div>
      )}

      {saveDialogOpen && (
          <SaveDialog titleId="project-save-title" busy={busy === "save"} onCancel={() => setSaveDialogOpen(false)}>
            <div>
              <p className="eyebrow">Projektablage</p>
              <h2 id="project-save-title">{saveNewProject ? "Projekt anlegen und speichern" : "Projekt speichern"}</h2>
              <p>Die Projektdatei enthält Workflow, Engineering-Daten, Analysen, Simulationen und Governance-Historie.</p>
              <p>In SAVED wird das Projekt auf dem NIS-Server abgelegt. „Datei speichern unter“ öffnet die Dateiauswahl oder den Browser-Download.</p>
            </div>
            <label>
              <span>Projekt-ID</span>
              <input autoFocus readOnly={!saveNewProject} onChange={(event) => setProjectId(event.target.value)} value={projectId} />
            </label>
            {saveError && <p className="notice error" role="alert">{saveError}</p>}
            <div className="project-dialog-actions">
              <button className="button secondary" disabled={busy === "save"} onClick={() => setSaveDialogOpen(false)} type="button">Abbrechen</button>
              <button className="button secondary" disabled={busy === "save" || !projectId.trim()} onClick={() => void saveProject(saveNewProject ? projectId : undefined, true)} type="button">Datei speichern unter</button>
              <button className="button primary" disabled={busy === "save" || !projectId.trim()} onClick={() => void saveProject(saveNewProject ? projectId : undefined)} type="button">{busy === "save" ? "Speichert …" : "In SAVED speichern"}</button>
            </div>
          </SaveDialog>
      )}
    </>
  );
}
