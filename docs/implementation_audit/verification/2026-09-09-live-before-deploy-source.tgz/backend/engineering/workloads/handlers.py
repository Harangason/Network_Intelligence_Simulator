"""Spezialisierte Generatoren und Validatoren fuer Engineering-Workloads."""

from __future__ import annotations

import re
from copy import deepcopy
from typing import Any

from ..requirement_expansion import (
    WORKFLOW_STATUSES,
    expand_requirement,
)

from .registry import WorkloadHandler

SIGNAL_REQUIRED_FIELDS = (
    "id",
    "name",
    "display_name",
    "description",
    "category",
    "datatype",
    "unit",
    "minimum",
    "maximum",
    "resolution",
    "default_value",
    "invalid_value",
    "cycle_time",
    "producer",
    "consumers",
    "source",
    "generated_by",
    "confidence",
    "review_state",
)


def _signal(
    name: str,
    description: str,
    unit: str,
    minimum: float,
    maximum: float,
    resolution: float = 1.0,
    datatype: str = "unsigned",
) -> dict[str, Any]:
    return {
        "name": name,
        "description": description,
        "unit": unit,
        "minimum": minimum,
        "maximum": maximum,
        "resolution": resolution,
        "datatype": datatype,
    }


THERMAL_SIGNAL_CATALOG = (
    _signal("ThermalIsttemperatur", "Gefilterte aktuelle Temperatur der Thermal-ECU.", "degC", -40, 180, 0.1, "signed"),
    _signal("ThermalSolltemperatur", "Aktiver Temperatursollwert der Thermal-Regelung.", "degC", -40, 180, 0.1, "signed"),
    _signal("Kuehlmitteltemperatur", "Temperatur des Kuehlmittelkreises.", "degC", -40, 180, 0.1, "signed"),
    _signal("Motortemperatur", "Thermischer Zustand des Motors.", "degC", -40, 220, 0.1, "signed"),
    _signal("Invertertemperatur", "Thermischer Zustand des Inverters.", "degC", -40, 180, 0.1, "signed"),
    _signal("Temperaturgradient", "Zeitliche Aenderung der gemessenen Temperatur.", "degC/s", -100, 100, 0.1, "signed"),
    _signal("Heizanforderung", "Normierte Anforderung an die Heizleistung.", "%", 0, 100, 0.1),
    _signal("Kuehlanforderung", "Normierte Anforderung an die Kuehlleistung.", "%", 0, 100, 0.1),
    _signal("ThermischerStatus", "Kodierter Betriebszustand der Thermal-Regelung.", "code", 0, 15),
    _signal("TemperaturSensorQualitaet", "Qualitaetswert der Temperaturerfassung.", "%", 0, 100, 0.1),
)

MOTION_SIGNAL_CATALOG = (
    _signal("MotionFahrzeuggeschwindigkeit", "Berechnete Fahrzeuggeschwindigkeit.", "km/h", 0, 300, 0.01),
    _signal("MotionMotordrehzahl", "Aktuelle Motordrehzahl der Motion-ECU.", "rpm", 0, 20000),
    _signal("RaddrehzahlVorneLinks", "Raddrehzahl vorne links.", "rpm", 0, 3000),
    _signal("RaddrehzahlVorneRechts", "Raddrehzahl vorne rechts.", "rpm", 0, 3000),
    _signal("RaddrehzahlHintenLinks", "Raddrehzahl hinten links.", "rpm", 0, 3000),
    _signal("RaddrehzahlHintenRechts", "Raddrehzahl hinten rechts.", "rpm", 0, 3000),
    _signal("Laengsbeschleunigung", "Laengsbeschleunigung des Fahrzeugs.", "m/s2", -30, 30, 0.01, "signed"),
    _signal("Querbeschleunigung", "Querbeschleunigung des Fahrzeugs.", "m/s2", -30, 30, 0.01, "signed"),
    _signal("Gierrate", "Drehgeschwindigkeit um die Hochachse.", "deg/s", -250, 250, 0.01, "signed"),
    _signal("Lenkwinkel", "Aktueller Lenkwinkel.", "deg", -720, 720, 0.1, "signed"),
    _signal("Fahrpedalstellung", "Normierte Fahrpedalstellung.", "%", 0, 100, 0.1),
    _signal("Bremsdruck", "Aktueller hydraulischer Bremsdruck.", "bar", 0, 250, 0.1),
    _signal("MotionSollmoment", "Angefordertes Antriebsmoment.", "Nm", -1000, 1000, 0.1, "signed"),
    _signal("MotionIstmoment", "Ermitteltes aktuelles Antriebsmoment.", "Nm", -1000, 1000, 0.1, "signed"),
    _signal("MotionMomentenlimit", "Aktives Momentenlimit.", "Nm", 0, 1000, 0.1),
    _signal("MotionMotorstrom", "Motorstrom im Motion-Regelkreis.", "A", -1000, 1000, 0.1, "signed"),
    _signal("Zwischenkreisspannung", "Spannung des elektrischen Zwischenkreises.", "V", 0, 1000, 0.1),
    _signal("MotionLeistungsaufnahme", "Elektrische Leistungsaufnahme des Antriebs.", "kW", -500, 500, 0.1, "signed"),
    _signal("MotionFahrmodus", "Kodierter aktiver Fahrmodus.", "code", 0, 15),
    _signal("Traktionsstatus", "Kodierter Zustand der Traktionsregelung.", "code", 0, 15),
    _signal("RadschlupfVorneLinks", "Berechneter Radschlupf vorne links.", "%", -100, 100, 0.01, "signed"),
    _signal("RadschlupfVorneRechts", "Berechneter Radschlupf vorne rechts.", "%", -100, 100, 0.01, "signed"),
    _signal("RadschlupfHintenLinks", "Berechneter Radschlupf hinten links.", "%", -100, 100, 0.01, "signed"),
    _signal("RadschlupfHintenRechts", "Berechneter Radschlupf hinten rechts.", "%", -100, 100, 0.01, "signed"),
    _signal("MotionFehlercode", "Aggregierter Diagnosecode der Motion-ECU.", "code", 0, 65535),
)

SIGNAL_CATALOGS = {
    "thermal": THERMAL_SIGNAL_CATALOG,
    "motion": MOTION_SIGNAL_CATALOG,
}

SIGNAL_ALIAS_GROUPS = (
    ("motordrehzahl", "enginespeed", "motorrpm", "rotationalspeed"),
    ("fahrzeuggeschwindigkeit", "vehiclespeed", "speed"),
    ("isttemperatur", "temperaturecurrent", "actualtemperature"),
    ("solltemperatur", "temperaturetarget", "targettemperature"),
    ("laengsbeschleunigung", "longitudinalacceleration"),
    ("querbeschleunigung", "lateralacceleration"),
)


def normalized_name(value: Any) -> str:
    text = str(value or "").lower()
    text = text.replace("ä", "a").replace("ö", "o").replace("ü", "u").replace("ß", "ss")
    return re.sub(r"[^a-z0-9]+", "", text)


def snake_case_name(value: Any) -> str:
    text = str(value or "").replace("ß", "ss")
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", text)
    text = text.lower()
    text = text.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return re.sub(r"_+", "_", text).strip("_")


_BUS_NAME_TOKENS = re.compile(
    r"(?:^|_)(?:can_fd|can|lin|flexray|ethernet|ethercat|profinet|modbustcp|modbusrtu|rs232|rs485|spi|i2c|usb|pcie|mqtt|opcua)(?=_|$)",
    re.IGNORECASE,
)
_MESSAGE_SUFFIX = re.compile(r"(?:_)?(?:data|message|nachricht|aktor|actor|sensor|status|command|steuerung)$", re.IGNORECASE)
_INITIAL_ALIASES = {"gateway": "gw", "system_gateway": "sgw", "systemgateway": "sgw"}


def pascal_case_name(value: Any) -> str:
    return "".join(token[:1].upper() + token[1:] for token in snake_case_name(value).split("_") if token)


def normalize_interface_name(value: Any) -> str:
    base = re.sub(r"_+", "_", _BUS_NAME_TOKENS.sub("_", snake_case_name(value))).strip("_")
    if not base:
        return str(value or "")
    return "_".join(token if token.isdigit() else token[:1].upper() + token[1:] for token in base.split("_"))


def normalize_message_name(value: Any) -> str:
    base = re.sub(r"_+", "_", _BUS_NAME_TOKENS.sub("_", snake_case_name(value))).strip("_")
    base = _MESSAGE_SUFFIX.sub("", base) or base
    return pascal_case_name(base or value)


def signal_initials(value: Any) -> str:
    base = _MESSAGE_SUFFIX.sub("", snake_case_name(value))
    if base in _INITIAL_ALIASES:
        return _INITIAL_ALIASES[base]
    tokens = [token for token in base.split("_") if token]
    if len(tokens) > 1:
        return "".join(token[0] for token in tokens)
    token = tokens[0] if tokens else ""
    consonants = re.sub(r"[aeiou]", "", token)
    return (consonants[:2] or token[:2] or "sig").lower()


def normalize_signal_name(value: Any, message_name: Any = None) -> str:
    base = re.sub(r"^sig_", "", snake_case_name(value))
    base = re.sub(r"_signal$", "", base) or "signal"
    if not str(message_name or "").strip():
        return base
    prefix = signal_initials(message_name)
    if base.startswith(f"{prefix}_") and base.endswith(f"_{prefix}"):
        return base
    return f"{prefix}_{base}_{prefix}"


def normalize_workload_candidate(target: str, definition: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(definition)
    if target == "Interface" and normalized.get("name"):
        normalized["name"] = normalize_interface_name(normalized["name"])
    elif target == "Message" and normalized.get("name"):
        normalized["name"] = normalize_message_name(normalized["name"])
    elif target == "Signal" and normalized.get("name"):
        normalized["name"] = normalize_signal_name(normalized["name"], normalized.get("message_name") or normalized.get("message_id"))
        normalized.setdefault("display_name", normalized["name"])
    return normalized


def suggest_candidate_repair(target: str, definition: dict[str, Any]) -> dict[str, Any]:
    repaired = normalize_workload_candidate(target, dict(definition))
    if target == "Message":
        repaired.setdefault("direction", "tx")
        repaired.setdefault("cycle_ms", 10)
        repaired.setdefault("dlc", 8)
        repaired.setdefault("configuration", {})
        repaired.setdefault("description", f"Kommunikationsnachricht fuer {repaired.get('name') or 'Funktion'}.")
    elif target == "Signal":
        message_name = repaired.get("message_name") or repaired.get("message_id")
        if repaired.get("name"):
            repaired["name"] = normalize_signal_name(repaired["name"], message_name)
            repaired.setdefault("display_name", repaired["name"])
        repaired.setdefault("byte_order", "little_endian")
        repaired.setdefault("data_type", repaired.get("datatype") or "unsigned")
        repaired.setdefault("factor", repaired.get("resolution") or 1)
        repaired.setdefault("offset_value", 0)
        repaired.setdefault("unit", repaired.get("unit") or "code")
        repaired.setdefault("min_value", repaired.get("minimum") if repaired.get("minimum") is not None else 0)
        repaired.setdefault("max_value", repaired.get("maximum") if repaired.get("maximum") is not None else 255)
        repaired.setdefault("configuration", {})
        repaired.setdefault("semantic", {})
        repaired.setdefault("data", {})
        repaired.setdefault("communication", {})
        repaired.setdefault("quality", {})
        repaired.setdefault("protocol_bindings", [])
    return repaired


def semantic_alias_key(value: Any) -> str:
    key = normalized_name(value)
    for index, aliases in enumerate(SIGNAL_ALIAS_GROUPS):
        if any(alias in key for alias in aliases):
            return f"alias-group-{index}"
    return key


def _default_value(minimum: float, maximum: float) -> float:
    if minimum <= 0 <= maximum:
        return 0
    return minimum


def _semantic_type_for_signal(name: str, unit: str, minimum: float, maximum: float) -> str:
    key = f"{name} {unit}".lower()
    if minimum == 0 and maximum == 1 and any(token in key for token in ("status", "flag", "aktiv", "enable", "boolean")):
        return "BOOLEAN"
    if any(token in key for token in ("status", "state", "mode", "zustand", "diagnose", "fehler", "code")) or unit == "code":
        return "STATE"
    return "NUMERIC"


def _state_value_domain(name: str) -> dict[str, Any]:
    key = name.lower()
    if "gateway" in key:
        enum_values = {
            "OFF": 0,
            "INIT": 1,
            "CONFIGURING": 2,
            "READY": 3,
            "ACTIVE": 4,
            "STANDBY": 5,
            "SHUTTING_DOWN": 6,
            "ERROR": 7,
        }
        timeline = [
            {"state": "OFF", "from_s": 0.0, "to_s": 0.1},
            {"state": "INIT", "from_s": 0.1, "to_s": 0.5},
            {"state": "CONFIGURING", "from_s": 0.5, "to_s": 1.2},
            {"state": "READY", "from_s": 1.2, "to_s": 1.5},
            {"state": "ACTIVE", "from_s": 1.5, "to_s": None},
        ]
    elif any(token in key for token in ("kommunikation", "connect", "gateway", "bus", "link")):
        enum_values = {
            "OFFLINE": 0,
            "INITIALIZING": 1,
            "CONNECTED": 2,
            "PARTIAL": 3,
            "BUS_OFF": 4,
            "LINK_LOSS": 5,
            "ERROR": 6,
        }
        timeline = [
            {"state": "OFFLINE", "from_s": 0.0, "to_s": 0.2},
            {"state": "INITIALIZING", "from_s": 0.2, "to_s": 1.0},
            {"state": "CONNECTED", "from_s": 1.0, "to_s": None},
        ]
    else:
        enum_values = {
            "OFF": 0,
            "INIT": 1,
            "SELF_TEST": 2,
            "READY": 3,
            "RUNNING": 4,
            "DEGRADED": 5,
            "ERROR": 6,
            "SHUTDOWN": 7,
        }
        timeline = [
            {"state": "OFF", "from_s": 0.0, "to_s": 0.2},
            {"state": "INIT", "from_s": 0.2, "to_s": 0.8},
            {"state": "SELF_TEST", "from_s": 0.8, "to_s": 1.4},
            {"state": "READY", "from_s": 1.4, "to_s": 2.0},
            {"state": "RUNNING", "from_s": 2.0, "to_s": None},
        ]
    reserved_values = [value for value in range(0, 16) if value not in set(enum_values.values())]
    return {
        "enum_values": enum_values,
        "allowed_values": list(enum_values),
        "reserved_values": reserved_values,
        "invalid_values": [15],
        "default_value": next(iter(enum_values)),
        "state_timeline": timeline,
        "resolution": 1,
    }


def _canonical_signal_layers(
    *,
    name: str,
    description: str,
    category: str,
    datatype: str,
    unit: str,
    minimum: float,
    maximum: float,
    resolution: float,
    producer: str,
    consumers: list[str],
    cycle_time: float,
    length_bits: int,
    start_bit: int,
) -> dict[str, Any]:
    semantic_type = _semantic_type_for_signal(name, unit, minimum, maximum)
    if semantic_type == "BOOLEAN":
        value_domain = {
            "minimum": 0,
            "maximum": 1,
            "resolution": 1,
            "allowed_values": [False, True],
            "enum_values": {"FALSE": 0, "TRUE": 1},
            "invalid_values": [],
            "reserved_values": [],
            "default_value": False,
        }
    elif semantic_type == "STATE":
        value_domain = _state_value_domain(name)
    else:
        value_domain = {
            "minimum": minimum,
            "maximum": maximum,
            "resolution": resolution,
            "allowed_values": [],
            "enum_values": {},
            "invalid_values": [maximum + resolution],
            "reserved_values": [],
            "default_value": _default_value(minimum, maximum),
        }
    return {
        "semantic": {
            "semantic_type": semantic_type,
            "quantity": name,
            "category": category,
            "meaning": description,
            "unit": unit if semantic_type == "NUMERIC" else "not_applicable",
            "generated_by": "engineering-workload-signal-generator-v2",
            "assumptions": [] if semantic_type == "NUMERIC" else ["Diskretes Signal wurde als explizite Value-Domain modelliert."],
        },
        "data": value_domain,
        "configuration": {
            "raw_datatype": datatype,
            "bit_length": length_bits,
            "signed": datatype == "signed",
            "factor": resolution,
            "offset": 0,
            "endianness": "little_endian",
            "start_bit": start_bit,
            "encoding_type": "linear" if semantic_type == "NUMERIC" else "coded",
            "coding_rule": "MEANING_VALUE_DOMAIN_ENCODING_PACKING_TRANSPORT",
        },
        "communication": {
            "cycle_time_ms": cycle_time,
            "producer": producer,
            "consumers": consumers,
            "update_type": "cyclic_fast" if cycle_time <= 20 else "cyclic",
        },
        "quality": {
            "confidence": 0.95 if semantic_type == "NUMERIC" else 0.88,
            "semantic_complete": True,
            "value_domain_complete": True,
            "encoding_complete": True,
            "packing_complete": True,
            "validation_status": "proposal",
        },
        "protocol_bindings": [],
    }


def _signal_definition(
    workload: dict[str, Any],
    package: dict[str, Any],
    candidate: dict[str, Any],
    context: dict[str, Any],
    index: int,
) -> dict[str, Any]:
    minimum = float(candidate["minimum"])
    maximum = float(candidate["maximum"])
    resolution = float(candidate["resolution"])
    message = context["message"]
    producer = str(context["node"].get("name") or package["category"])
    cycle_time = float(message.get("cycle_ms") or 10)
    signal_name = normalize_signal_name(candidate["name"], message.get("name"))
    identifier = f"{workload['workload_id']}:{normalized_name(signal_name)}"
    start_bit = index * 16
    layers = _canonical_signal_layers(
        name=signal_name,
        description=str(candidate["description"]),
        category=str(package["category"]),
        datatype=str(candidate["datatype"]),
        unit=str(candidate["unit"]),
        minimum=minimum,
        maximum=maximum,
        resolution=resolution,
        producer=producer,
        consumers=list(context.get("consumers") or []),
        cycle_time=cycle_time,
        length_bits=16,
        start_bit=start_bit,
    )
    return {
        "id": identifier,
        "object_type": "Signal",
        "resource": "signals",
        "name": signal_name,
        "display_name": signal_name,
        "description": candidate["description"],
        "category": package["category"],
        "datatype": candidate["datatype"],
        "data_type": candidate["datatype"],
        "unit": candidate["unit"],
        "minimum": minimum,
        "min_value": minimum,
        "maximum": maximum,
        "max_value": maximum,
        "resolution": resolution,
        "factor": resolution,
        "offset_value": 0,
        "default_value": _default_value(minimum, maximum),
        "invalid_value": maximum + resolution,
        "cycle_time": cycle_time,
        "producer": producer,
        "consumers": list(context.get("consumers") or []),
        "source": "ai_generated",
        "generated_by": "engineering-workload-signal-generator-v2",
        "confidence": 0.95,
        "review_state": "unreviewed",
        "approval_state": "pending",
        "domain": str(workload.get("domain") or "automotive"),
        "message_id": str(message["id"]),
        "start_bit": start_bit,
        "length_bits": 16,
        "byte_order": "little_endian",
        **layers,
    }


def _existing_signal_definition(
    workload: dict[str, Any],
    package: dict[str, Any],
    candidate: dict[str, Any],
    existing: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    minimum = existing.get("min_value") if existing.get("min_value") is not None else candidate["minimum"]
    maximum = existing.get("max_value") if existing.get("max_value") is not None else candidate["maximum"]
    resolution = existing.get("factor") if existing.get("factor") not in (None, 0) else candidate["resolution"]
    communication = dict(existing.get("communication") or {})
    semantic = dict(existing.get("semantic") or {})
    producer = str(communication.get("producer") or semantic.get("owner") or context["node"].get("name") or package["category"])
    return {
        **_signal_definition(workload, package, candidate, context, 0),
        "id": str(existing["id"]),
        "name": normalize_signal_name(existing.get("name") or candidate["name"], context["message"].get("name")),
        "display_name": str(existing.get("display_name") or existing.get("name") or candidate["name"]),
        "description": str(existing.get("description") or candidate["description"]),
        "datatype": str(existing.get("data_type") or candidate["datatype"]),
        "data_type": str(existing.get("data_type") or candidate["datatype"]),
        "unit": existing.get("unit") or candidate["unit"] or "not_applicable",
        "minimum": float(minimum),
        "min_value": float(minimum),
        "maximum": float(maximum),
        "max_value": float(maximum),
        "resolution": float(resolution),
        "factor": float(resolution),
        "default_value": (existing.get("data") or {}).get("default_value", _default_value(float(minimum), float(maximum))),
        "invalid_value": (existing.get("data") or {}).get("invalid_value", float(maximum) + float(resolution)),
        "cycle_time": float(communication.get("cycle_time_ms") or context["message"].get("cycle_ms") or 10),
        "producer": producer,
        "consumers": list(communication.get("consumers") or []),
        "source": str(existing.get("source") or "manual"),
        "generated_by": str((existing.get("provenance") or {}).get("model") or "existing-engineering-model"),
        "confidence": float(existing.get("confidence") if existing.get("confidence") is not None else 1.0),
        "review_state": str(existing.get("review_state") or "reviewed"),
        "approval_state": str(existing.get("approval_state") or "approved"),
    }


def validate_signal_definition(definition: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for field in SIGNAL_REQUIRED_FIELDS:
        value = definition.get(field)
        if value is None or value == "" or (field == "consumers" and not isinstance(value, list)):
            findings.append({"code": "MISSING_FIELD", "field": field, "severity": "ERROR"})
    minimum = definition.get("minimum")
    maximum = definition.get("maximum")
    resolution = definition.get("resolution")
    if isinstance(minimum, (int, float)) and isinstance(maximum, (int, float)) and minimum > maximum:
        findings.append({"code": "INVALID_RANGE", "field": "minimum", "severity": "ERROR"})
    if not isinstance(resolution, (int, float)) or resolution <= 0:
        findings.append({"code": "INVALID_RESOLUTION", "field": "resolution", "severity": "ERROR"})
    default = definition.get("default_value")
    if (
        isinstance(default, (int, float))
        and isinstance(minimum, (int, float))
        and isinstance(maximum, (int, float))
        and not minimum <= default <= maximum
    ):
        findings.append({"code": "DEFAULT_OUT_OF_RANGE", "field": "default_value", "severity": "ERROR"})
    if definition.get("datatype") not in {"signed", "unsigned", "float", "boolean", "enum"}:
        findings.append({"code": "INVALID_DATATYPE", "field": "datatype", "severity": "ERROR"})
    confidence = definition.get("confidence")
    if not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
        findings.append({"code": "INVALID_CONFIDENCE", "field": "confidence", "severity": "ERROR"})
    return findings


class SignalGenerationWorkloadHandler(WorkloadHandler):
    workload_type = "SIGNAL_GENERATION"

    def plan(self, orchestrator, workload: dict[str, Any], packages: list[dict[str, Any]]) -> None:
        for package in packages:
            orchestrator.unblock_package(package)
            category = str(package["category"]).lower()
            if category not in SIGNAL_CATALOGS:
                orchestrator.block_package(
                    package,
                    "UNSUPPORTED_SIGNAL_CATEGORY",
                    f"Fuer {category!r} ist kein fachlich belastbarer Signalgenerator registriert.",
                )
                continue
            if int(package["requested_count"]) > len(SIGNAL_CATALOGS[category]):
                orchestrator.block_package(
                    package,
                    "INSUFFICIENT_DOMAIN_KNOWLEDGE",
                    f"Der Katalog enthaelt {len(SIGNAL_CATALOGS[category])} belastbare Signale, angefordert sind {package['requested_count']}.",
                )
                continue
            context = orchestrator.build_context(workload, package)["engineering"]
            if not context.get("node") or not context.get("engineering_interface"):
                orchestrator.block_package(
                    package,
                    "MISSING_ENGINEERING_DEPENDENCY",
                    f"Fuer {category} fehlen ECU oder Kommunikationsinterface.",
                )
            elif not context.get("message"):
                orchestrator.ensure_message_dependency(workload, package, context)

    def execute(self, orchestrator, workload: dict[str, Any], package: dict[str, Any]) -> dict[str, Any]:
        if str(package.get("status")) == "BLOCKED":
            return {"status": "SUCCESS", "requested": package["requested_count"], "generated": 0, "valid": 0, "invalid": 0, "objects": [], "validation_findings": package.get("findings") or [], "remaining": package["requested_count"]}
        category = str(package["category"]).lower()
        context = orchestrator.build_context(workload, package)["engineering"]
        if not context.get("message"):
            orchestrator.block_package(package, "MISSING_MESSAGE_DEPENDENCY", "Die benoetigte Container-Message ist noch nicht freigegeben.")
            return {"status": "SUCCESS", "requested": package["requested_count"], "generated": 0, "valid": 0, "invalid": 0, "objects": [], "validation_findings": [{"code": "MISSING_MESSAGE_DEPENDENCY"}], "remaining": package["requested_count"]}

        existing_signals = orchestrator.list_canonical_objects("Signal")
        workload_objects = orchestrator.list_workload_objects(str(workload["workload_id"]), str(package["work_package_id"]))
        generator = self.select_generator(orchestrator, package)
        generated = generator.generate(
            int(package["requested_count"]),
            workload=workload,
            package=package,
            context={**context, "workload_objects": workload_objects},
            existing=existing_signals,
        )
        proposals: list[dict[str, Any]] = []
        generated_keys: list[str] = []
        for item in generated.objects:
            key = str(item["object_key"])
            definition = dict(item["definition"])
            if item.get("canonical_id"):
                orchestrator.upsert_workload_object(
                    workload,
                    package,
                    key,
                    definition,
                    canonical_id=str(item["canonical_id"]),
                    approval_state=str(item.get("approval_state") or "APPROVED"),
                    review_state=str(item.get("review_state") or "REVIEWED"),
                )
            else:
                proposals.append(definition)
                generated_keys.append(key)

        if proposals:
            proposal = orchestrator.create_validated_proposal(workload, package, "Signal", proposals)
            for index, definition in enumerate(proposals):
                orchestrator.upsert_workload_object(
                    workload,
                    package,
                    generated_keys[index],
                    definition,
                    proposal_id=str(proposal["proposal_id"]),
                    proposal_index=index,
                    review_state="READY_FOR_REVIEW" if proposal.get("status") == "READY_FOR_REVIEW" else "DRAFT",
                )
        objects = orchestrator.list_workload_objects(str(workload["workload_id"]), str(package["work_package_id"]))
        return {
            "status": "SUCCESS",
            "requested": int(package["requested_count"]),
            "generated": len(objects),
            "valid": sum(bool(item.get("is_valid")) for item in objects),
            "invalid": sum(not bool(item.get("is_valid")) for item in objects),
            "objects": [str(item["workload_object_id"]) for item in objects],
            "validation_findings": [finding for item in objects for finding in item.get("validation_results") or []],
            "remaining": max(0, int(package["requested_count"]) - len(objects)),
            "generator": type(generator).__name__,
        }

    def validate(self, orchestrator, workload: dict[str, Any]) -> dict[str, Any]:
        objects = orchestrator.list_workload_objects(str(workload["workload_id"]))
        identifiers: dict[str, str] = {}
        names: dict[str, str] = {}
        concepts: dict[str, str] = {}
        for item in objects:
            definition = dict(item.get("definition") or {})
            findings = validate_signal_definition(definition)
            identifier_key = normalized_name(definition.get("id"))
            name_key = normalized_name(definition.get("name"))
            concept_key = semantic_alias_key((definition.get("semantic") or {}).get("concept") or name_key)
            duplicate_of = identifiers.get(identifier_key) or names.get(name_key) or concepts.get(concept_key)
            if identifier_key and identifier_key in identifiers:
                findings.append({"code": "DUPLICATE_ID", "severity": "ERROR", "duplicate_of": duplicate_of})
            elif name_key and name_key in names:
                findings.append({"code": "DUPLICATE_NAME", "severity": "ERROR", "duplicate_of": duplicate_of})
            elif duplicate_of:
                findings.append({"code": "POSSIBLE_DUPLICATE", "severity": "ERROR", "duplicate_of": duplicate_of})
            else:
                identifiers[identifier_key] = str(item["workload_object_id"])
                names[name_key] = str(item["workload_object_id"])
                concepts[concept_key] = str(item["workload_object_id"])
            orchestrator.update_workload_object_validation(
                item,
                definition,
                findings,
                duplicate_of=duplicate_of,
            )
        orchestrator.recount_packages(str(workload["workload_id"]))
        return {"status": "SUCCESS", "validated": len(objects)}

    def repair(self, orchestrator, workload: dict[str, Any]) -> dict[str, Any]:
        repaired = 0
        for item in orchestrator.list_workload_objects(str(workload["workload_id"])):
            findings = item.get("validation_results") or []
            if item.get("is_valid") or any(finding.get("code") == "POSSIBLE_DUPLICATE" for finding in findings if isinstance(finding, dict)):
                continue
            definition = deepcopy(item.get("definition") or {})
            minimum = definition.get("minimum")
            maximum = definition.get("maximum")
            if isinstance(minimum, (int, float)) and isinstance(maximum, (int, float)) and minimum > maximum:
                definition["minimum"], definition["maximum"] = maximum, minimum
                definition["min_value"], definition["max_value"] = maximum, minimum
            if not isinstance(definition.get("resolution"), (int, float)) or definition.get("resolution", 0) <= 0:
                definition["resolution"] = 1
                definition["factor"] = 1
            if definition.get("unit") in (None, ""):
                definition["unit"] = "not_applicable"
            if not isinstance(definition.get("consumers"), list):
                definition["consumers"] = []
            if definition.get("default_value") is None and isinstance(definition.get("minimum"), (int, float)) and isinstance(definition.get("maximum"), (int, float)):
                definition["default_value"] = _default_value(definition["minimum"], definition["maximum"])
            if definition.get("invalid_value") is None and isinstance(definition.get("maximum"), (int, float)):
                definition["invalid_value"] = definition["maximum"] + float(definition.get("resolution") or 1)
            if definition != item.get("definition"):
                orchestrator.replace_workload_object_definition(item, definition)
                repaired += 1
        if repaired:
            orchestrator.sync_workload_proposals(str(workload["workload_id"]))
        return {"status": "SUCCESS", "repaired": repaired}


class StructuredObjectWorkloadHandler(WorkloadHandler):
    """Generic counted handler for registry types with explicit candidates."""

    def __init__(self, workload_type: str) -> None:
        self.workload_type = workload_type

    def plan(self, orchestrator, workload: dict[str, Any], packages: list[dict[str, Any]]) -> None:
        for package in packages:
            candidates = (package.get("configuration") or {}).get("candidate_objects")
            if not isinstance(candidates, list) or len(candidates) < int(package["requested_count"]):
                orchestrator.block_package(
                    package,
                    "INSUFFICIENT_DOMAIN_KNOWLEDGE",
                    "Es liegen nicht genug fachlich begruendete candidate_objects vor; Quantitaet wird nicht halluziniert.",
                )

    def execute(self, orchestrator, workload: dict[str, Any], package: dict[str, Any]) -> dict[str, Any]:
        raw_candidates = list((package.get("configuration") or {}).get("candidate_objects") or [])[: int(package["requested_count"])]
        if str(package.get("status")) == "BLOCKED":
            return {"status": "SUCCESS", "requested": package["requested_count"], "generated": 0, "valid": 0, "invalid": 0, "objects": [], "validation_findings": package.get("findings") or [], "remaining": package["requested_count"]}
        proposal = None
        target = str(workload["target_object"])
        candidates = [normalize_workload_candidate(target, dict(candidate)) for candidate in raw_candidates]
        if target in {"HardwareNode", "Function", "Interface", "Message", "Signal"}:
            proposal = orchestrator.create_validated_proposal(workload, package, target, candidates)
        for index, candidate in enumerate(candidates):
            definition = dict(candidate)
            definition.setdefault("object_type", target)
            definition.setdefault("category", package["category"])
            definition.setdefault("id", f"{workload['workload_id']}:{package['package_code']}:{index + 1}")
            key = f"{target.lower()}:{package['category']}:{normalized_name(definition.get('name') or definition['id'])}"
            orchestrator.upsert_workload_object(
                workload,
                package,
                key,
                definition,
                proposal_id=str(proposal["proposal_id"]) if proposal else None,
                proposal_index=index if proposal else None,
                review_state="READY_FOR_REVIEW" if proposal and proposal.get("status") == "READY_FOR_REVIEW" else "DRAFT",
            )
        return {"status": "SUCCESS", "requested": package["requested_count"], "generated": len(candidates), "valid": 0, "invalid": 0, "objects": [], "validation_findings": [], "remaining": max(0, int(package["requested_count"]) - len(candidates))}

    def validate(self, orchestrator, workload: dict[str, Any]) -> dict[str, Any]:
        objects = orchestrator.list_workload_objects(str(workload["workload_id"]))
        names: dict[str, str] = {}
        for item in objects:
            definition = dict(item.get("definition") or {})
            findings = []
            if not definition.get("id"):
                findings.append({"code": "MISSING_FIELD", "field": "id", "severity": "ERROR"})
            if not definition.get("name") and workload["target_object"] not in {"Documentation", "TraceAnalysis", "NetworkAnalysis", "BusLoadAnalysis"}:
                findings.append({"code": "MISSING_FIELD", "field": "name", "severity": "ERROR"})
            expected = suggest_candidate_repair(str(workload["target_object"]), definition)
            if definition.get("name") and expected.get("name") != definition.get("name"):
                findings.append(
                    {
                        "code": "CANONICAL_NAME_REPAIR_AVAILABLE",
                        "severity": "ERROR",
                        "field": "name",
                        "current": definition.get("name"),
                        "suggested": expected.get("name"),
                        "message": "Name folgt nicht dem kanonischen Engineering-Schema.",
                    }
                )
            key = normalized_name(definition.get("name") or definition.get("id"))
            duplicate_of = names.get(key)
            if duplicate_of:
                findings.append({"code": "POSSIBLE_DUPLICATE", "severity": "ERROR", "duplicate_of": duplicate_of})
            else:
                names[key] = str(item["workload_object_id"])
            orchestrator.update_workload_object_validation(item, definition, findings, duplicate_of=duplicate_of)
        orchestrator.recount_packages(str(workload["workload_id"]))
        return {"status": "SUCCESS", "validated": len(objects)}

    def repair(self, orchestrator, workload: dict[str, Any]) -> dict[str, Any]:
        repaired = 0
        delete_marked = 0
        target = str(workload["target_object"])
        for item in orchestrator.list_workload_objects(str(workload["workload_id"])):
            findings = [finding for finding in item.get("validation_results") or [] if isinstance(finding, dict)]
            if not findings:
                continue
            definition = dict(item.get("definition") or {})
            if any(finding.get("code") in {"POSSIBLE_DUPLICATE", "DUPLICATE_NAME", "DUPLICATE_ID"} for finding in findings):
                if item.get("canonical_id"):
                    proposal = orchestrator.create_review_proposal(
                        workload,
                        item,
                        target,
                        {
                            **definition,
                            "canonical_id": str(item["canonical_id"]),
                            "proposal_action": "DELETE",
                            "proposal_state": "READY_FOR_REVIEW",
                            "ai_recommendation": "Ueberzaehliges oder doppeltes Objekt entfernen beziehungsweise ausmustern.",
                        },
                        prompt="KI-Audit: ueberzaehliges Objekt zur Entfernung markieren",
                    )
                    orchestrator.attach_object_to_proposal(item, proposal, 0)
                    delete_marked += 1
                continue
            suggestion = suggest_candidate_repair(target, definition)
            if suggestion == definition:
                continue
            suggestion.update(
                {
                    "proposal_action": "UPDATE" if item.get("canonical_id") else "CREATE",
                    "proposal_state": "READY_FOR_REVIEW",
                    "ai_recommendation": "Kanonische Parameter wurden aus Generatorregeln und ML-/Audit-Hinweisen vorgeschlagen.",
                }
            )
            if item.get("canonical_id"):
                suggestion["canonical_id"] = str(item["canonical_id"])
                proposal = orchestrator.create_review_proposal(
                    workload,
                    item,
                    target,
                    suggestion,
                    prompt="KI-Audit: Objektparameter korrigieren",
                )
                orchestrator.attach_object_to_proposal(item, proposal, 0)
            else:
                orchestrator.replace_workload_object_definition(item, suggestion)
            repaired += 1
        if repaired:
            orchestrator.sync_workload_proposals(str(workload["workload_id"]))
        return {
            "status": "SUCCESS",
            "repaired": repaired,
            "delete_marked": delete_marked,
            "note": "Korrekturen wurden als Review-Proposals bereitgestellt; automatische Uebernahme erfolgt nicht.",
        }


class RequirementExpansionWorkloadHandler(WorkloadHandler):
    workload_type = "REQUIREMENT_EXPANSION"

    def plan(self, orchestrator, workload: dict[str, Any], packages: list[dict[str, Any]]) -> None:
        raw_prompt = str(workload.get("prompt") or "").strip()
        if not raw_prompt:
            for package in packages:
                orchestrator.block_package(package, "EMPTY_REQUIREMENT", "Die Anforderung ist leer")
            return

        for package in packages:
            orchestrator.unblock_package(package)
            if int(package["requested_count"]) != 1:
                orchestrator.block_package(
                    package,
                    "INVALID_PACKAGE_COUNT",
                    "Requirement Expansion erzeugt genau einen Ergebnis-Paketblock.",
                )

    def execute(self, orchestrator, workload: dict[str, Any], package: dict[str, Any]) -> dict[str, Any]:
        if str(package.get("status")) == "BLOCKED":
            return {
                "status": "BLOCKED",
                "requested": int(package["requested_count"]),
                "generated": 0,
                "valid": 0,
                "invalid": 0,
                "objects": [],
                "validation_findings": package.get("findings") or [],
                "remaining": package["requested_count"],
            }

        result = expand_requirement(
            str(workload.get("prompt") or ""),
            domain=str(workload.get("domain") or "automotive"),
            model=str(workload.get("model") or "engineering-workload-orchestrator"),
        )

        definition = {
            "object_type": "Documentation",
            "name": "RequirementExpansionDraft",
            "title": "Requirement Expansion Proposal",
            "id": f"{workload['workload_id']}:{package['package_code']}",
            "status": result["status"],
            "workflow_status": result["workflow_status"],
            "interpretation": result["interpretation"],
            "ambiguity": result["ambiguity"],
            "assumptions": result["assumptions"],
            "functions": result["functions"],
            "sensors": result["sensors"],
            "coordinate_system": result["coordinate_system"],
            "parameters": result["parameters"],
            "status_models": result["status_models"],
            "data_objects": result["data_objects"],
            "signals": result["signals"],
            "hardware": result["hardware"],
            "communications": result["communications"],
            "messages": result["messages"],
            "routing": result["routing"],
            "capacity": result["capacity"],
            "open_decisions": result["open_decisions"],
            "findings": result["findings"],
            "completion": result["completion"],
            "provenance": result["provenance"],
            "confidence": result["confidence"],
            "assumptions_status": result["assumptions_status"],
            "open_decisions_status": result["open_decisions_status"],
            "generated_by": "engineer-requirement-expansion-handler",
            "domain": workload.get("domain") or "automotive",
            "source_prompt": str(workload.get("prompt") or ""),
        }

        orchestrator.upsert_workload_object(
            workload,
            package,
            key := f"requirement-expansion:{package['package_code']}",
            definition,
            review_state="READY_FOR_REVIEW",
            approval_state="PENDING",
        )

        objects = orchestrator.list_workload_objects(str(workload["workload_id"]), str(package["work_package_id"]))
        return {
            "status": "SUCCESS",
            "requested": int(package["requested_count"]),
            "generated": len(objects),
            "valid": sum(bool(item.get("is_valid")) for item in objects),
            "invalid": sum(not bool(item.get("is_valid")) for item in objects),
            "objects": [str(item["workload_object_id"]) for item in objects],
            "validation_findings": [finding for item in objects for finding in item.get("validation_results") or []],
            "remaining": max(0, int(package["requested_count"]) - len(objects)),
        }

    def validate(self, orchestrator, workload: dict[str, Any]) -> dict[str, Any]:
        objects = orchestrator.list_workload_objects(str(workload["workload_id"]))
        for item in objects:
            definition = dict(item.get("definition") or {})
            findings: list[dict[str, Any]] = []
            if definition.get("status") != "OK":
                findings.append({"code": "INVALID_STATUS", "severity": "ERROR", "message": "Status der Expansion muss OK sein."})
            if str(definition.get("workflow_status") or "") not in WORKFLOW_STATUSES:
                findings.append({"code": "INVALID_WORKFLOW_STATUS", "severity": "ERROR", "message": "Ungueltiger Workflow-Status."})
            if not definition.get("interpretation"):
                findings.append({"code": "MISSING_INTERPRETATION", "severity": "ERROR", "message": "Interpretation fehlt."})
            if not definition.get("functions"):
                findings.append({"code": "MISSING_FUNCTIONS", "severity": "ERROR", "message": "Funktionen fehlen."})
            if not definition.get("sensors"):
                findings.append({"code": "MISSING_SENSORS", "severity": "ERROR", "message": "Sensorik fehlt."})
            required_sections = (
                "parameters",
                "status_models",
                "data_objects",
                "signals",
                "hardware",
                "communications",
                "messages",
                "routing",
                "capacity",
                "completion",
            )
            for section in required_sections:
                if not definition.get(section):
                    findings.append({"code": "MISSING_REQUIREMENT_EXPANSION_SECTION", "field": section, "severity": "ERROR"})
            capacity = definition.get("capacity") or {}
            for field in ("raw_mbit_s", "effective_mbit_s", "suggested_technology", "cycle_time_ms", "latency_budget_ms"):
                if capacity.get(field) is None:
                    findings.append({"code": "MISSING_CAPACITY_FIELD", "field": field, "severity": "ERROR"})
            messages = definition.get("messages") or []
            for message in messages:
                if not isinstance(message, dict):
                    findings.append({"code": "INVALID_MESSAGE", "severity": "ERROR"})
                    continue
                if not message.get("name") or not message.get("transport"):
                    findings.append({"code": "INCOMPLETE_MESSAGE_PACKING", "field": str(message.get("name") or "unknown"), "severity": "ERROR"})
                if message.get("transport") == "CAN_FD" and message.get("packed_payload_bytes") not in (8, 12, 16, 20, 24, 32, 48, 64):
                    findings.append({"code": "INVALID_CAN_FD_PAYLOAD", "field": str(message.get("name") or "unknown"), "severity": "ERROR"})
            routing = definition.get("routing") or []
            for route in routing:
                if not isinstance(route, dict) or not route.get("from") or not route.get("to") or not route.get("media"):
                    findings.append({"code": "INCOMPLETE_ROUTING", "severity": "ERROR"})
            completion = definition.get("completion") or {}
            if completion.get("ready_for_auto_apply") is not False:
                findings.append({"code": "MISSING_HUMAN_REVIEW_GATE", "severity": "ERROR", "message": "Requirement Expansion darf nicht automatisch angewendet werden."})
            orchestrator.update_workload_object_validation(item, definition, findings)
        orchestrator.recount_packages(str(workload["workload_id"]))
        return {"status": "SUCCESS", "validated": len(objects)}

    def repair(self, orchestrator, workload: dict[str, Any]) -> dict[str, Any]:
        repaired = 0
        for item in orchestrator.list_workload_objects(str(workload["workload_id"])):
            definition = dict(item.get("definition") or {})
            changed = False
            if definition.get("assumptions_status") != "REQUIRED_REVIEW" and definition.get("assumptions_status") != "COMPLETED":
                definition["assumptions_status"] = "REQUIRED_REVIEW" if definition.get("open_decisions") else "COMPLETED"
                changed = True
            if not definition.get("confidence"):
                definition["confidence"] = 0.75
                changed = True
            if changed:
                orchestrator.replace_workload_object_definition(item, definition)
                repaired += 1
        if repaired:
            orchestrator.sync_workload_proposals(str(workload["workload_id"]))
        return {"status": "SUCCESS", "repaired": repaired}
