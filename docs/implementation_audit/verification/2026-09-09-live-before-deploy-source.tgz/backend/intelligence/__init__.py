"""Structured intelligence extensions."""
