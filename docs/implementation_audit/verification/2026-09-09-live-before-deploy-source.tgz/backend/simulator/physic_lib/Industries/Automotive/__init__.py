"""Automotive communication domain."""
