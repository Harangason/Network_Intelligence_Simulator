"""Building automation communication domain."""
