"""Energy communication domain."""
