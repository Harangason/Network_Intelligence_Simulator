"""Industrial automation communication domain."""
