"""Marine communication domain."""
