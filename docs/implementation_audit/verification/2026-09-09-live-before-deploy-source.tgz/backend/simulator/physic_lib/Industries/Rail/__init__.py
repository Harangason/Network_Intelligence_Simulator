"""Rail communication domain."""
