import { test, expect, type Page } from 'playwright/test';
import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const steps = ['engineering_model', 'routing', 'network_editor', 'parameters', 'capacity_timing',
  'validation', 'simulation', 'results_analysis', 'data_science_intelligence'];
const done = new Set(['COMPLETE', 'APPROVED', 'WARNING']);

async function readProject(page: Page, project: string, path: string) {
  const result = await page.request.get(path, { headers: { 'X-Project-ID': project }, timeout: 60_000 });
  expect(result.ok(), await result.text()).toBeTruthy();
  return result.json();
}

async function openWizard(page: Page, project: string) {
  await page.goto(`/studio/engineering?assistant=project&project=${project}`, { waitUntil: 'load' });
  const dialog = page.getByRole('dialog', { name: 'Engineering-Auftrag erstellen' });
  await expect(dialog).toBeVisible();
  return dialog;
}

async function verifyArtifacts(page: Page, project: string, minimumSignals: number) {
  const workflow = await readProject(page, project, '/api/engineering/workflow?view=summary');
  expect(Object.keys(workflow.statuses).sort()).toEqual([...steps].sort());
  for (const step of steps) expect(done.has(workflow.statuses[step]), `${step}: ${workflow.statuses[step]}`).toBeTruthy();
  const jobs = (await readProject(page, project, '/api/simulations')).jobs;
  expect(jobs).toHaveLength(1);
  expect(jobs[0].status).toBe('completed');
  const snapshots = await readProject(page, project, '/api/engineering/workflow/snapshots');
  const snapshot = snapshots.simulations.find((item: { job_id: string }) => item.job_id === jobs[0].id);
  expect(snapshot).toBeTruthy();
  const full = await readProject(page, project, `/api/engineering/workflow/simulation-snapshots/${snapshot.id}`);
  const assessment = full.result.assessment;
  expect(assessment.scope_coverage.scope_mode).toBe('ALL');
  expect(assessment.scope_coverage.complete).toBe(true);
  expect(assessment.conformance).toBe('PASS');
  expect(assessment.failed_route_count).toBe(0);
  expect(assessment.observed_signal_count).toBeGreaterThanOrEqual(minimumSignals);
  for (const key of ['missing_observed_signal_ids', 'missing_observed_route_ids', 'missing_observed_network_ids']) expect(assessment[key]).toEqual([]);
  const trace = await readProject(page, project, `/api/simulations/${jobs[0].id}/trace-window?limit=10`);
  expect(trace.count).toBeGreaterThan(0);
  expect(trace.events.some((item: { signals?: unknown[] }) => item.signals && Object.keys(item.signals).length)).toBeTruthy();
  return { workflow, job: jobs[0].id, assessment };
}

async function completeThroughWizard(page: Page, project: string, restart: boolean) {
  let reviewCount = 0;
  let runId: string | undefined;
  const reviewed = new Set<string>();
  for (let checkpoint = 0; checkpoint < 16; checkpoint++) {
    let workflow: any;
    await expect.poll(async () => {
      workflow = await readProject(page, project, '/api/engineering/workflow?view=summary');
      return steps.every(step => done.has(workflow.statuses[step]))
        || ['REVIEW_REQUIRED', 'READY_TO_CONTINUE', 'BLOCKED', 'FAILED', 'INCOMPLETE'].includes(workflow.context.agent_execution?.state);
    }, { timeout: 240_000, intervals: [500, 1000, 2000] }).toBe(true);
    runId ??= workflow.context.agent_execution?.run_id;
    expect(workflow.context.agent_execution?.run_id).toBe(runId);
    if (steps.every(step => done.has(workflow.statuses[step]))) return { runId, reviewed: [...reviewed] };
    const execution = workflow.context.agent_execution;
    const dialog = page.getByRole('dialog', { name: 'Engineering-Auftrag erstellen' });
    if (['BLOCKED', 'FAILED', 'INCOMPLETE'].includes(execution?.state)) {
      const conversation = await readProject(page, project, '/api/engineering/agent/conversation');
      const id = conversation.data?.active_proposal;
      const proposal = id ? await readProject(page, project, `/api/engineering/agent/proposals/${id}`) : null;
      throw new Error(JSON.stringify({ execution, proposal: proposal?.data?.validation_result, visible: await dialog.innerText() }));
    }
    if (execution?.state === 'READY_TO_CONTINUE') {
      const button = dialog.getByRole('button', { name: 'Auftrag fortsetzen', exact: true });
      await expect(button).toBeEnabled();
      await button.click();
      await expect.poll(async () => (await readProject(page, project, '/api/engineering/workflow?view=summary')).context.agent_execution?.updated_at,
        { timeout: 60_000 }).not.toBe(execution.updated_at);
      continue;
    }
    const conversation = await readProject(page, project, '/api/engineering/agent/conversation');
    const proposalId = conversation.data.active_proposal;
    expect(reviewed.has(proposalId), 'The same proposal must not request review twice.').toBe(false);
    const applyResponse = page.waitForResponse(response => response.url().includes(`/proposals/${proposalId}/apply`) && response.request().method() === 'POST', { timeout: 180_000 });
    const approval = dialog.getByRole('button', { name: /^(Freigeben, übernehmen & fortfahren|Übernehmen & fortfahren)$/ });
    await expect(approval).toBeEnabled({ timeout: 60_000 });
    await approval.click();
    const applied = await applyResponse;
    expect(applied.ok(), await applied.text()).toBeTruthy();
    expect((await applied.json()).data.status).toBe('APPLIED');
    reviewed.add(proposalId); reviewCount++;
    if (reviewCount === 1) await openWizard(page, project); // Durable reload after a real commit.
    if (restart && reviewCount === 2) {
      const container = process.env.NIS_E2E_APP_CONTAINER!;
      expect(container).toMatch(/^nis-e2e-app-[a-f0-9]+$/);
      const docker = process.env.NIS_TEST_DOCKER || 'docker';
      const label = execFileSync(docker, ['inspect', container, '--format', '{{index .Config.Labels "networkis.test"}}'], { encoding: 'utf8' }).trim();
      expect(label).toBe('disposable');
      execFileSync(docker, ['restart', container]);
      await expect.poll(async () => {
        try { return (await page.request.get('/api/ready', { timeout: 2000 })).ok(); } catch { return false; }
      }, { timeout: 120_000 }).toBe(true);
      await openWizard(page, project);
    }
    await expect.poll(async () => {
      const current = await readProject(page, project, '/api/engineering/workflow?view=summary');
      return current.context.agent_execution?.updated_at !== execution.updated_at;
    }, { timeout: 60_000 }).toBe(true);
  }
  throw new Error('Wizard exceeded 16 review/continuation checkpoints.');
}

test('new small wizard traverses all nine stages and survives reload/restart @small', async ({ page }, testInfo) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  const project = 'nis-e2e-small-' + randomUUID();
  const dialog = await openWizard(page, project);
  await dialog.getByTitle('Projektname', { exact: true }).click();
  await dialog.locator('#engineering-project-name').fill('E2E small');
  await dialog.getByTitle('Aufgabe', { exact: true }).click();
  await dialog.getByLabel('Aufgabentext', { exact: true }).fill('Erzeuge ein Automotive CAN-FD Netzwerk mit einem Gateway System, den ECUs Motorsteuerung und Anzeige, einem Sensor MotorTemperature und einem Aktor MotorValve. MotorTemperature wird von Motorsteuerung ausgewertet. Motorsteuerung steuert MotorValve. Statuswerte werden an Anzeige und System übermittelt. Prüfe und arbeite bis Data Science & Intelligence.');
  await dialog.getByLabel('Weitere Hinweise', { exact: true }).fill('- Aktor-Befehle: {"MotorValve":{"length_bits":1,"data_type":"boolean","factor":1,"unit":"code","min_value":0,"max_value":1,"semantic":{"semantic_type":"BOOLEAN"},"data":{"enum_values":{"CLOSE":0,"OPEN":1}}}}');
  await dialog.getByTitle('Geräteumfang', { exact: true }).click();
  for (const [label, value] of [['Gateways', '1'], ['Controller', '2'], ['Sensoren', '1'], ['Aktoren', '1']]) await dialog.getByLabel(`${label}: verbindliche Anzahl`, { exact: true }).fill(value);
  // Use the same visible questionnaire navigation a user uses; never inject generated model rows.
  for (let step = 0; step < 10; step++) {
    const submit = dialog.locator('.eng-agent-questionnaire-head').getByRole('button');
    await expect(submit).toBeEnabled();
    const name = await submit.innerText();
    await submit.click();
    if (name === 'Übernehmen') break;
    if (step === 9) throw new Error('Questionnaire did not offer submit.');
  }
  const continuity = await completeThroughWizard(page, project, true);
  const artifacts = await verifyArtifacts(page, project, 5);
  await openWizard(page, project);
  expect((await readProject(page, project, '/api/simulations')).jobs).toHaveLength(1);
  expect(errors).toEqual([]);
  await testInfo.attach('evidence', { body: JSON.stringify({ project, ...continuity, ...artifacts }), contentType: 'application/json' });
});

test('exact confirmed 50/250/250 request completes through real wizard review @large', async ({ page }, testInfo) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  const project = 'nis-e2e-large-' + randomUUID();
  const runId = randomUUID();
  const original = await readFile(new URL('./fixtures/wizard-large-50-250-250.txt', import.meta.url), 'utf8');
  const metadata = JSON.parse(await readFile(new URL('./fixtures/wizard-large-50-250-250.json', import.meta.url), 'utf8'));
  const prompt = original.replace(/^- Lauf-ID:.*$/m, '- Lauf-ID: ' + runId);
  // Replay the captured, already confirmed input through the normal START API.
  // All proposal inspection, approval, continuation and reloads below use UI.
  const started = await page.request.post('/api/engineering/agent/chat', {
    headers: { 'X-Project-ID': project }, timeout: 240_000,
    data: { prompt, wizard_command: { action: 'START', run_id: runId, operation_id: randomUUID(),
      target: 'data_science_intelligence', wizard_context: { ...metadata.wizard_context, project_id: project, run_id: runId } } },
  });
  expect(started.ok(), await started.text()).toBeTruthy();
  await openWizard(page, project);
  const continuity = await completeThroughWizard(page, project, false);
  expect(continuity.runId).toBe(runId);
  const artifacts = await verifyArtifacts(page, project, 1404);
  expect(errors).toEqual([]);
  await testInfo.attach('evidence', { body: JSON.stringify({ project, fixture: metadata.request_sha256, ...continuity, ...artifacts }), contentType: 'application/json' });
});
