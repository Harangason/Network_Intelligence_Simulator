"use workflow"

import { generateText } from "ai"
import { fal } from "@fal-ai/client"
import { put } from "@vercel/blob"

// Configure fal client with API key - without this, all fal.ai calls return "Forbidden"
fal.config({
  credentials: process.env.FAL_KEY,
})

/**
 * Parse fal.ai errors into user-friendly messages.
 * fal.ai returns HTTP status codes in the error body/message for auth, credits, and rate limits.
 */
function parseFalError(error: unknown, context: string): Error {
  const msg = (error as Error).message || String(error)
  const statusMatch = msg.match(/(\d{3})/)
  const status = statusMatch ? parseInt(statusMatch[1]) : 0

  if (status === 401 || msg.includes("Unauthorized")) {
    return new Error(`${context}: Invalid FAL_KEY. Please check your API key in Settings > Vars.`)
  }
  if (status === 403 || msg.includes("Forbidden")) {
    return new Error(
      `${context}: Access denied. This usually means your fal.ai account has insufficient credits or your plan does not include this model. ` +
      `Please check your balance at https://fal.ai/dashboard/billing and add credits.`
    )
  }
  if (status === 429 || msg.includes("Too Many Requests") || msg.includes("rate limit")) {
    return new Error(`${context}: Rate limit exceeded. Please wait a moment and try again.`)
  }
  if (status === 422 || msg.includes("Unprocessable")) {
    return new Error(`${context}: Invalid input parameters. ${msg}`)
  }
  if (msg.includes("timeout") || msg.includes("Timeout") || msg.includes("ETIMEDOUT")) {
    return new Error(`${context}: Request timed out. The model may be under heavy load. Please try again.`)
  }
  return new Error(`${context}: ${msg}`)
}
import type { Node, Edge } from "@xyflow/react"
import type { StreamUpdate, ExecutionResult } from "@/lib/types"
import { createRun, addStep, updateStep, completeRun } from "@/lib/runs-store"
import {
  getMemory,
  saveMemory,
  getAllMemories,
  addMessage,
  getRecentMessages,
  getOrCreateConversation,
  formatMessagesForContext,
  formatMemoriesForContext,
} from "@/lib/memory"

const isWorkflowActive = true; // Declare the variable here

export const maxDuration = 300

function interpolateVariables(template: string, inputs: unknown[]): string {
  let result = template
  inputs.forEach((input, index) => {
    const placeholder = `$input${index + 1}`
    const value = typeof input === "string" ? input : JSON.stringify(input)
    result = result.replace(new RegExp(`\\${placeholder}`, "g"), value)
  })
  return result
}

function getNodeName(node: Node): string {
  const labels: Record<string, string> = {
    start: "Start",
    end: "End",
    textModel: "Text Model",
    prompt: "Prompt",
    conditional: "Condition",
    httpRequest: "HTTP Request",
    imageGeneration: "Image Generation",
    javascript: "JavaScript",
    audio: "Audio",
    embeddingModel: "Embedding",
    tool: "Tool",
    structuredOutput: "Structured Output",
    memory: "Memory",
    ugcModel: "UGC Model",
    productUpload: "Product Upload",
    script: "Video Script",
    videoGeneration: "Video Generation",
  }
  return labels[node.type || ""] || node.type || "Unknown"
}

export async function POST(req: Request) {
  const encoder = new TextEncoder()
  const stream = new ReadableStream({
    async start(controller) {
      const sendUpdate = (update: StreamUpdate & { runId?: string }) => {
        controller.enqueue(encoder.encode(JSON.stringify(update) + "\n"))
      }

      let currentRun: ReturnType<typeof createRun> | null = null

      try {
        const { nodes, edges, stopAtNodeId }: { nodes: Node[]; edges: Edge[]; stopAtNodeId?: string } = await req.json()

        // Validate FAL_KEY early to prevent cryptic errors later
        const hasFalNodes = nodes.some((n) => 
          n.type === "imageGeneration" || n.type === "videoGeneration"
        )
        if (hasFalNodes && !process.env.FAL_KEY) {
          throw new Error("FAL_KEY environment variable is required for image/video generation. Please add it in Settings.")
        }

        // Create run with workflow snapshot
        currentRun = createRun({ nodes, edges })
        sendUpdate({ type: "run_started" as any, runId: currentRun.id })

        const nodeMap = new Map(nodes.map((node) => [node.id, node]))
        const results = new Map<string, unknown>()
        const executionLog: ExecutionResult[] = []
        let stoppedAtNode = false

        const incomingEdges = new Set(edges.map((e) => e.target))
        const entryNodes = nodes.filter((node) => !incomingEdges.has(node.id))
        
        // If stopAtNodeId is provided, find the path to that node
        const shouldStopAt = (nodeId: string) => {
          if (!stopAtNodeId) return false
          return nodeId === stopAtNodeId
        }

        const executeNode = async (nodeId: string): Promise<unknown> => {
          "use step"

          if (results.has(nodeId)) {
            return results.get(nodeId)
          }

          const node = nodeMap.get(nodeId)
          if (!node) {
            throw new Error(`Node ${nodeId} not found`)
          }

          const inputEdges = edges
            .filter((e) => e.target === nodeId)
            .sort((a, b) => {
              const nodeA = nodeMap.get(a.source)
              const nodeB = nodeMap.get(b.source)
              return (nodeA?.position.x || 0) - (nodeB?.position.x || 0)
            })

          let hasValidInput = inputEdges.length === 0

          for (const edge of inputEdges) {
            const sourceNode = nodeMap.get(edge.source)

            if (sourceNode?.type === "conditional") {
              if (results.has(edge.source)) {
                const conditionResult = results.get(edge.source)
                const expectedHandle = conditionResult ? "true" : "false"
                if (!edge.sourceHandle || edge.sourceHandle === expectedHandle) {
                  hasValidInput = true
                  break
                }
              }
            } else {
              const sourceResult = await executeNode(edge.source)
              if (sourceResult !== null) {
                hasValidInput = true
                break
              }
            }
          }

          if (!hasValidInput) {
            results.set(nodeId, null)
            return null
          }

          const stepStartTime = new Date().toISOString()
          if (currentRun) {
            addStep(currentRun.id, {
              nodeId,
              nodeType: node.type || "unknown",
              nodeName: getNodeName(node),
              status: "running",
              startedAt: stepStartTime,
            })
          }

          sendUpdate({
            type: "node_start",
            nodeId,
            nodeType: node.type,
            runId: currentRun?.id,
          })

          const inputs: unknown[] = []
          for (const edge of inputEdges) {
            const sourceNode = nodeMap.get(edge.source)
            let shouldIncludeInput = true

            if (sourceNode?.type === "conditional" && results.has(edge.source)) {
              const conditionResult = results.get(edge.source)
              const expectedHandle = conditionResult ? "true" : "false"
              if (edge.sourceHandle && edge.sourceHandle !== expectedHandle) {
                shouldIncludeInput = false
              }
            }

            if (shouldIncludeInput) {
              const inputResult = await executeNode(edge.source)
              if (inputResult !== null) {
                inputs.push(inputResult)
              }
            }
          }

          if (inputEdges.length > 0 && inputs.length === 0) {
            results.set(nodeId, null)
            return null
          }

          let output: unknown

          try {
            switch (node.type) {
              case "start":
                output = "Workflow started"
                break

              case "end":
                output = inputs.length > 0 ? inputs[0] : null
                break

              case "conditional": {
                const conditionCode = node.data.condition || "true"
                try {
                  const func = new Function(
                    "inputs",
                    `const input1 = inputs[0]; const input2 = inputs[1]; const input3 = inputs[2]; return ${conditionCode};`,
                  )
                  output = Boolean(func(inputs))
                } catch (condError) {
                  throw new Error(`Conditional evaluation error: ${(condError as Error).message}`)
                }
                break
              }

              case "httpRequest": {
                let url = node.data.url || ""
                const method = node.data.method || "GET"

                if (inputs.length > 0) {
                  url = interpolateVariables(url, inputs)
                }

                const headers: Record<string, string> = {}
                if (node.data.headers) {
                  try {
                    Object.assign(headers, JSON.parse(node.data.headers))
                  } catch {
                    // Invalid headers JSON
                  }
                }

                let body = node.data.body || ""
                if (body && inputs.length > 0) {
                  body = interpolateVariables(body, inputs)
                }

                const fetchOptions: RequestInit = { method, headers }
                if (method !== "GET" && method !== "HEAD" && body) {
                  fetchOptions.body = body
                }

                const response = await fetch(url, fetchOptions)
                output = await response.json()
                break
              }

              case "prompt": {
                const content = node.data.content || ""
                output = inputs.length > 0 ? interpolateVariables(content, inputs) : content
                break
              }

              case "textModel": {
                const prompt = inputs.length > 0 ? String(inputs[0]) : node.data.prompt || ""
                const model = node.data.model || "openai/gpt-5-mini"
                const temperature = node.data.temperature || 0.7
                const maxTokens = node.data.maxTokens || 2000

                const textResult = await generateText({
                  model,
                  prompt,
                  temperature,
                  maxTokens,
                })
                output = textResult.text
                break
              }

              case "imageGeneration": {
                // Check if image is locked and has a saved image
                if (node.data.isLocked && node.data.lockedImageUrl) {
                  output = node.data.lockedImageUrl
                  break
                }

                const imageModel = node.data.model || "google/gemini-2.5-flash-image"
                const aspectRatio = node.data.aspectRatio || "1:1"

                // Parse inputs: look for UGC model params, product data, and text prompts
                let ugcParams: { gender?: string; ethnicity?: string; ageRange?: string; description?: string; lockedImageUrl?: string } | null = null
                let productData: { image?: string; name?: string } | null = null
                const textInputs: string[] = []

                for (const input of inputs) {
                  if (typeof input === "object" && input !== null) {
                    if ((input as any).type === "ugc-model-params") {
                      // UGC Model parameters
                      ugcParams = input as any
                    } else if ((input as any).type === "product-upload") {
                      // Product data with name and image
                      productData = {
                        image: (input as any).image,
                        name: (input as any).name,
                      }
                    }
                  } else if (typeof input === "string") {
                    if (input.startsWith("data:image/")) {
                      // Legacy: bare product image (for backwards compatibility)
                      productData = { image: input, name: "" }
                    } else if (input.trim()) {
                      textInputs.push(input)
                    }
                  }
                }

                // Build the prompt
                let imagePrompt = ""

                if (ugcParams) {
                  // UGC workflow: generate a realistic image of model holding product
                  // If locked image exists, skip generation and return it
                  if (ugcParams.lockedImageUrl) {
                    output = ugcParams.lockedImageUrl
                    break
                  }

                  // Build detailed prompt for realistic UGC image
                  const gender = ugcParams.gender || "female"
                  const ethnicity = ugcParams.ethnicity || "caucasian"
                  const ageRange = ugcParams.ageRange || "26-35"
                  const description = ugcParams.description || ""
                  
                  // Get product name for the prompt
                  const productName = productData?.name || ""
                  const hasProduct = productData?.image || productName

                  // Build product description for the prompt
                  let productDescription = ""
                  if (productName) {
                    productDescription = productName
                  } else if (productData?.image) {
                    productDescription = "a product"
                  }

                  // For Flux Edit models: the input image IS the product image.
                  // We need to prompt the model to EDIT the scene around the product,
                  // placing it in the hands of a person. This is image-to-image editing.
                  imagePrompt = `Transform this product image into a UGC-style photograph. Place this exact product in the hands of a ${gender} ${ethnicity} person, age ${ageRange}, who is presenting it to the camera.

EDITING INSTRUCTIONS:
- Keep the product EXACTLY as shown in the input image - same shape, colors, labels, packaging
- Generate a realistic ${gender} person of ${ethnicity} ethnicity, aged ${ageRange}, holding this product
- The person should have a warm, genuine smile and look directly at the camera
- Natural skin texture, realistic features, no distortion
- Well-lit indoor setting with soft, professional lighting
- Casual clothing, natural pose as if filming a product review
${description ? `- Person details: ${description}` : ""}

QUALITY REQUIREMENTS:
- Photorealistic quality, no artifacts or distortion
- Correctly formed hands with 5 fingers each, naturally gripping the product
- Sharp focus on both the person's face and the product
- No text overlays, watermarks, UI elements, or phone screens
- Single person only, no duplicates
- ${aspectRatio === "9:16" ? "Vertical portrait" : aspectRatio === "16:9" ? "Horizontal landscape" : "Square"} composition`

                } else if (textInputs.length > 0) {
                  // Standard text prompt
                  imagePrompt = textInputs.join(" ")
                } else {
                  throw new Error("Image generation requires UGC model parameters or a text prompt")
                }

                const images: string[] = []

                // Require product image for image-to-image models
                if (!productData?.image) {
                  throw new Error("Image generation requires a product image. Please upload a product image.")
                }

                // Use fal.ai Flux 2 image-to-image models
                // These models take the product image as input and edit the scene around it
                const editPrompt = imagePrompt

                let result: any

                try {
                  if (imageModel === "fal-ai/flux-2-pro/edit") {
                    // Flux 2 Pro Edit - highest quality image-to-image
                    result = await fal.subscribe("fal-ai/flux-2-pro/edit", {
                      input: {
                        prompt: editPrompt,
                        image_urls: [productData.image],
                        image_size: "auto",
                        safety_tolerance: "2",
                        output_format: "jpeg",
                      },
                    })
                  } else if (imageModel === "fal-ai/flux-2/lora/edit") {
                    // Flux 2 LoRA Edit - with LoRA support
                    result = await fal.subscribe("fal-ai/flux-2/lora/edit", {
                      input: {
                        prompt: editPrompt,
                        image_urls: [productData.image],
                        guidance_scale: 2.5,
                        num_inference_steps: 28,
                        output_format: "jpeg",
                      },
                    })
                  } else {
                    throw new Error(`Unsupported image model: ${imageModel}`)
                  }
                } catch (falError) {
                  throw parseFalError(falError, "Image generation failed")
                }

                // Handle both direct response and wrapped response from fal
                const imageUrl = result.data?.images?.[0]?.url || result.images?.[0]?.url
                
                if (imageUrl) {
                  // Fetch the image from fal
                  const imageResponse = await fetch(imageUrl)
                  const imageBuffer = await imageResponse.arrayBuffer()
                  
                  // Upload to Vercel Blob for a public URL (needed for video generation)
                  const filename = `ugc-model-${Date.now()}.jpg`
                  const blob = await put(filename, Buffer.from(imageBuffer), {
                    access: "public",
                    contentType: "image/jpeg",
                  })
                  
                  images.push(blob.url)
                }

                if (images.length === 0) {
                  throw new Error("No image was generated. Try adjusting the model settings.")
                }

                // Output is the public Blob URL for the generated image
                output = images[0]
                break
              }

              case "javascript": {
                const jsCode = node.data.code || ""
                try {
                  const func = new Function(
                    "inputs",
                    "args",
                    `const input1 = inputs[0]; const input2 = inputs[1]; const input3 = inputs[2]; const input4 = inputs[3]; const input5 = inputs[4]; ${jsCode}`,
                  )
                  output = await func(inputs, {})
                } catch (jsError) {
                  throw new Error(`JavaScript execution error: ${(jsError as Error).message}`)
                }
                break
              }

              case "audio":
                output = {
                  audioUrl: "Audio generation placeholder",
                  text: inputs.length > 0 ? String(inputs[0]) : "",
                  model: node.data.model,
                  voice: node.data.voice,
                }
                break

              case "embeddingModel":
                output = { embedding: "Embedding generation not implemented in demo" }
                break

              case "structuredOutput":
                output = { message: "Structured output not implemented in demo" }
                break

              case "tool": {
                if (node.data.code) {
                  try {
                    const func = new Function(
                      "inputs",
                      "args",
                      `const input1 = inputs[0]; const input2 = inputs[1]; const input3 = inputs[2]; ${node.data.code}`,
                    )
                    output = await func(inputs, {})
                  } catch (toolError) {
                    throw new Error(`Tool execution error: ${(toolError as Error).message}`)
                  }
                } else {
                  output = { message: "Tool has no implementation code" }
                }
                break
              }

              case "memory": {
                const operation = node.data.operation || "load"
                const sessionId = node.data.sessionId || "default"
                const key = node.data.key || ""
                const memoryType = node.data.memoryType || "fact"
                const messageRole = node.data.messageRole || "user"
                const limit = node.data.limit || 10

                switch (operation) {
                  case "load": {
                    const memory = await getMemory(sessionId, key)
                    output = memory ? memory.value : null
                    break
                  }
                  case "save": {
                    const valueToSave = inputs.length > 0 ? String(inputs[0]) : ""
                    if (key && valueToSave) {
                      const savedMemory = await saveMemory(sessionId, key, valueToSave, memoryType)
                      output = { saved: true, key, value: savedMemory.value }
                    } else {
                      output = { saved: false, error: "Missing key or value" }
                    }
                    break
                  }
                  case "loadAll": {
                    const memories = await getAllMemories(sessionId)
                    output = formatMemoriesForContext(memories)
                    break
                  }
                  case "addMessage": {
                    const conversation = await getOrCreateConversation(sessionId)
                    const content = inputs.length > 0 ? String(inputs[0]) : ""
                    if (content) {
                      const message = await addMessage(conversation.id, messageRole, content)
                      output = { added: true, messageId: message.id }
                    } else {
                      output = { added: false, error: "Missing content" }
                    }
                    break
                  }
                  case "getMessages": {
                    const messages = await getRecentMessages(sessionId, limit)
                    output = formatMessagesForContext(messages)
                    break
                  }
                  default:
                    output = { error: "Unknown memory operation" }
                }
                break
              }

              case "ugcModel": {
                // UGC Model node outputs parameters only (NOT an image)
                // These parameters are used by the Image Generation node to create the final image
                const gender = node.data.gender || "female"
                const ethnicity = node.data.ethnicity || "caucasian"
                const ageRange = node.data.ageRange || "26-35"
                const description = node.data.description || ""

                // Output the model parameters as an object
                output = {
                  type: "ugc-model-params",
                  gender,
                  ethnicity,
                  ageRange,
                  description,
                  // If locked, include the locked image URL for video generation
                  lockedImageUrl: node.data.isLocked ? node.data.lockedImageUrl : undefined,
                }
                break
              }

              case "productUpload": {
                // Output both the product image and name for the image generation prompt
                const productImage = node.data.productImage
                const productName = node.data.productName || ""
                
                if (!productImage) {
                  throw new Error("No product image uploaded. Please upload a product image.")
                }

                // Convert base64 data URL to a public Vercel Blob URL
                // fal.ai requires HTTP URLs, not base64 data URIs
                let productImageUrl = productImage
                if (productImage.startsWith("data:")) {
                  const matches = productImage.match(/^data:([^;]+);base64,(.+)$/)
                  if (matches) {
                    const contentType = matches[1]
                    const base64Data = matches[2]
                    const buffer = Buffer.from(base64Data, "base64")
                    const ext = contentType.split("/")[1] || "png"
                    const filename = `product-${Date.now()}.${ext}`
                    const blob = await put(filename, buffer, {
                      access: "public",
                      contentType,
                    })
                    productImageUrl = blob.url
                  }
                }
                
                output = {
                  type: "product-upload",
                  image: productImageUrl,
                  name: productName,
                }
                break
              }

              case "script": {
                // Return the script text for video generation
                const script = node.data.script || ""
                if (!script.trim()) {
                  throw new Error("No script provided. Please enter dialogue for the video.")
                }
                output = script
                break
              }

              case "videoGeneration": {
                // Get inputs: model image URL, product data, and script
                // inputs[0] = model image URL (from imageGeneration - uploaded to Vercel Blob)
                // inputs[1] = product data (from productUpload)
                // inputs[2] = script (from script node)

                // Find the model image URL from inputs - it should be a Vercel Blob URL
                let modelImageUrl: string | null = null
                let productData: { type?: string; image?: string; name?: string } | null = null
                let videoScript = ""

                for (const input of inputs) {
                  if (typeof input === "string") {
                    // Check for any HTTPS URL (Vercel Blob, fal.media, etc.)
                    if (input.startsWith("https://")) {
                      modelImageUrl = input
                    } else if (input.trim() && !input.startsWith("{") && !input.startsWith("data:")) {
                      // This is likely the script text
                      videoScript = input
                    }
                  } else if (typeof input === "object" && input !== null) {
                    const obj = input as Record<string, unknown>
                    if (obj.type === "product-upload") {
                      productData = obj as { type?: string; image?: string; name?: string }
                    }
                  }
                }

                // Validate the model image URL is still accessible
                if (modelImageUrl) {
                  try {
                    const headCheck = await fetch(modelImageUrl, { method: "HEAD" })
                    if (!headCheck.ok) {
                      throw new Error(`Model image URL is no longer accessible (HTTP ${headCheck.status}). Please regenerate the image.`)
                    }
                  } catch (fetchErr) {
                    if ((fetchErr as Error).message.includes("no longer accessible")) throw fetchErr
                    // Network error - try to proceed anyway
                  }
                }

                if (!modelImageUrl) {
                  throw new Error("Video generation requires a model image URL from the Image Generation node. Make sure the Image Generation node is connected and has completed.")
                }

                const aspectRatio = node.data.aspectRatio || "9:16"
                const duration = node.data.duration || "8s"
                const videoModel = node.data.model || "fal-ai/veo-3.1"

                // Get product name for context
                const productName = typeof productData === "object" && productData?.name 
                  ? productData.name 
                  : "product"

                // Build the video generation prompt for Fal AI Veo 3.1
                // The input image shows the person holding the product - animate them speaking
                let videoPrompt = `Animate this image into a UGC product review video. The person in the image begins speaking directly to the camera while naturally holding and presenting the ${productName}.

MOTION GUIDANCE:
- The person's lips move naturally as they speak
- Subtle head movements and natural facial expressions (smiling, nodding)
- Small hand gestures while holding the ${productName} - occasionally lifting or tilting it to show it off
- Natural eye contact with the camera throughout
- Slight body movement as if casually presenting to an audience

SCENE REQUIREMENTS:
- Maintain the same lighting, setting, and clothing from the input image
- Keep the ${productName} clearly visible and in frame at all times
- Professional quality, smooth motion, no jitter or artifacts
- The person looks authentic and enthusiastic, like a real content creator`

                // Build audio prompt from the script - this is what the person will say
                let audioPrompt = ""
                if (videoScript) {
                  audioPrompt = videoScript
                  videoPrompt += `\n\nThe person speaks this dialogue with natural enthusiasm and pacing:\n"${videoScript}"`
                }

                // Use fal.ai client for Veo 3.1 image-to-video with audio
                try {
                  // Determine the correct model endpoint
                  const falModelId = videoModel === "fal-ai/veo-3" 
                    ? "fal-ai/veo3/image-to-video"
                    : "fal-ai/veo3.1/image-to-video" // Veo 3.1 with audio support

                  const result = await fal.subscribe(falModelId, {
                    input: {
                      prompt: videoPrompt,
                      image_url: modelImageUrl, // Public URL from Vercel Blob
                      aspect_ratio: aspectRatio === "1:1" ? "9:16" : aspectRatio,
                      duration: duration,
                      // Veo 3.1 specific: enable audio generation with script
                      generate_audio: true,
                      audio_prompt: audioPrompt || undefined, // The actual speech content
                    },
                  })

                  // Handle both direct response and wrapped response from fal
                  const videoUrl = result.data?.video?.url || result.video?.url
                  
                  if (videoUrl) {
                    output = videoUrl
                  } else {
                    throw new Error("No video was generated. Please try again.")
                  }
                } catch (falError) {
                  throw parseFalError(falError, "Video generation failed")
                }
                break
              }

              default:
                output = null
            }

            results.set(nodeId, output)
            executionLog.push({ nodeId, type: node.type || "unknown", output })

            const stepEndTime = new Date().toISOString()
            if (currentRun) {
              updateStep(currentRun.id, nodeId, {
                status: "completed",
                completedAt: stepEndTime,
                duration: new Date(stepEndTime).getTime() - new Date(stepStartTime).getTime(),
                input: inputs.length > 0 ? inputs : undefined,
                output,
              })
            }

            sendUpdate({
              type: "node_complete",
              nodeId,
              nodeType: node.type,
              output,
              runId: currentRun?.id,
            })

            // Check if we should stop at this node
            if (shouldStopAt(nodeId)) {
              stoppedAtNode = true
              sendUpdate({
                type: "stopped_at_node" as any,
                nodeId,
                nodeType: node.type,
                output,
                runId: currentRun?.id,
              })
            }

            return output
          } catch (error) {
            const errorMessage = (error as Error).message || "Unknown error"
            executionLog.push({ nodeId, type: node.type || "unknown", output: null, error: errorMessage })

            if (currentRun) {
              updateStep(currentRun.id, nodeId, {
                status: "error",
                completedAt: new Date().toISOString(),
                error: errorMessage,
              })
            }

            sendUpdate({
              type: "node_error",
              nodeId,
              nodeType: node.type,
              error: errorMessage,
              runId: currentRun?.id,
            })

            throw error
          }
        }

        for (const entryNode of entryNodes) {
          if (stoppedAtNode) break
          await executeNode(entryNode.id)

          const processDownstream = async (nodeId: string) => {
            if (stoppedAtNode) return
            const outgoingEdges = edges.filter((e) => e.source === nodeId)
            for (const edge of outgoingEdges) {
              if (stoppedAtNode) return
              await executeNode(edge.target)
              if (stoppedAtNode) return
              await processDownstream(edge.target)
            }
          }
          await processDownstream(entryNode.id)
        }

        if (currentRun) {
          completeRun(currentRun.id, stoppedAtNode ? "stopped" : "completed")
        }

        sendUpdate({ 
          type: stoppedAtNode ? "stopped" : "complete", 
          executionLog, 
          runId: currentRun?.id,
          stoppedAtNodeId: stoppedAtNode ? stopAtNodeId : undefined 
        } as any)
        controller.close()
      } catch (error) {
        if (currentRun) {
          completeRun(currentRun.id, "failed")
        }

        sendUpdate({ type: "error", error: (error as Error).message || "Execution failed", runId: currentRun?.id })
        controller.close()
      }
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Transfer-Encoding": "chunked",
    },
  })
}
