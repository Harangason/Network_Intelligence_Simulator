import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const geistSans = Geist({ subsets: ["latin"], variable: "--font-geist-sans" })
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" })

export const metadata: Metadata = {
  title: {
    default: "UGC Video Agent Workflow",
    template: "%s | UGC Video Agent Workflow",
  },
  description:
    "Generate AI-powered UGC product videos in minutes. Visually build workflows that combine AI models, product images, scripts, and video generation - from product photo to publish-ready UGC content, all on a drag-and-drop canvas.",
  keywords: [
    "UGC",
    "user generated content",
    "AI video",
    "product video",
    "fal.ai",
    "Veo 3.1",
    "Flux",
    "workflow builder",
    "visual programming",
    "AI agents",
    "content creation",
    "React Flow",
    "Next.js",
    "Vercel",
  ],
  authors: [{ name: "v0" }],
  creator: "v0",
  publisher: "v0",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://v0-generated-agent-builder.vercel.app"),
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "/",
    title: "UGC Video Agent Workflow",
    description:
      "Generate AI-powered UGC product videos in minutes. Upload a product, configure an AI creator, write a script, and generate a publish-ready video - all on a visual drag-and-drop canvas.",
    siteName: "UGC Video Agent Workflow",
  },
  twitter: {
    card: "summary_large_image",
    title: "UGC Video Agent Workflow",
    description:
      "Build AI-powered UGC product videos visually. From product photo to publish-ready video with drag-and-drop workflow nodes.",
    creator: "@vercel",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  generator: "v0.app",
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fafafa" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a0a" },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                const stored = localStorage.getItem('theme');
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                
                if (stored === 'dark' || (stored === 'system' && prefersDark) || (!stored && prefersDark)) {
                  document.documentElement.classList.add('dark');
                } else {
                  document.documentElement.classList.remove('dark');
                }

                const resizeObserverErr = /ResizeObserver loop/;
                
                window.addEventListener('error', function(e) {
                  if (e.message && resizeObserverErr.test(e.message)) {
                    e.stopImmediatePropagation();
                    e.stopPropagation();
                    e.preventDefault();
                    return false;
                  }
                });

                window.addEventListener('unhandledrejection', function(e) {
                  if (e.reason && e.reason.message && resizeObserverErr.test(e.reason.message)) {
                    e.stopImmediatePropagation();
                    e.stopPropagation();
                    e.preventDefault();
                    return false;
                  }
                });

                // Suppress in console as well
                const originalError = console.error;
                console.error = function(...args) {
                  if (args[0] && typeof args[0] === 'string' && resizeObserverErr.test(args[0])) {
                    return;
                  }
                  originalError.apply(console, args);
                };
              })();
            `,
          }}
        />
      </head>
      <body className={`font-sans ${geistSans.variable} ${geistMono.variable}`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
