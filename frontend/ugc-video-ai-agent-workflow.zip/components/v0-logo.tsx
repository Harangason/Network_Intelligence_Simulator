"use client"

import { useTheme } from "next-themes"
import { useEffect, useState } from "react"

interface V0LogoProps {
  className?: string
  width?: number
  height?: number
}

export function V0Logo({ className, width = 24, height = 12 }: V0LogoProps) {
  const { resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // Avoid hydration mismatch
  if (!mounted) {
    return <div style={{ width, height }} />
  }

  const fill = resolvedTheme === "dark" ? "black" : "white"

  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 252 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        d="M96 86.0625V24H120V103.125C120 112.445 112.445 120 103.125 120C98.6751 120 94.2826 118.284 91.125 115.127L0 24H33.9375L96 86.0625Z"
        fill={fill}
      />
      <path
        d="M218.25 0C236.89 0 252 15.1104 252 33.75V96H228V41.0625L173.062 96H228V120H165.75C147.11 120 132 104.89 132 86.25V24H156V79.125L211.125 24H156V0H218.25Z"
        fill={fill}
      />
    </svg>
  )
}
