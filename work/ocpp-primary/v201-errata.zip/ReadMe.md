OCPP 2.0.1 Edition 4 - latest errata 2026-06
============

This zip contains the latest errata version of all OCPP 2.0.1 Edition 4 specification parts.


| File                                     | Date       |
| ---------------------------------------- | ---------- |
| OCPP-2.0.1_edition4_errata_2026-06.pdf   | 2026-07-13 |


### Additional information

The errata do not affect any schemas of OCPP messages. The errata do contain changes to requirements or even new requirements,
but only in cases where a requirement contains an obvious error and would not or could not be implemented literally. New
requirements were only added when they were already implicitly there. These changes have been discussed in or were proposed by
the Technology Working Group of the Open Charge Alliance.

### Older version of errata documents

All errata up to and including Errata version 2025-11 have been included in the OCPP 2.0.1 Edition 3 specification, resulting into OCPP 2.0.1 Edition 4 released on 2025-12-03.

All errata up to and including Errata version 2024-04 have been included in the OCPP 2.0.1 Edition 2 specification, resulting into OCPP 2.0.1 Edition 3 released on 2024-05-06.

As of the 2023-12-18 release of the errata document, it contains the errata for all parts of the OCPP 2.0.1 specification
(not only of OCPP 2.0.1 - Part 2 Specification)

Previously, two errata had been released for part 2 of the OCPP 2.0.1 specification:“OCPP-2.0.1_part2_errata_v1_0” was released in 2021.
In 2022 this version 1 document was *extended* with additional errata entries in “OCPP-2.0.1_part2_errata_v2_0”. These two errata have
been incorporated in “OCPP-2.0.1_part2_specification_edition2”, such that it is no longer necessary to read the errata in addition to
the “OCPP-2.0.1_part2_specification” (edition 1).