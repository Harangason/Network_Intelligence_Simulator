OCPP 2.1 Edition 2 - latest errata 2026-06
============

This zip contains the latest errata version of all OCPP 2.1 Edition 2 specification parts.


| File                                   | Date       |
| -------------------------------------- | ---------- |
| OCPP-2.1_edition2_errata_2026-06.pdf   | 2026-07-13 |


### Additional information

The errata do not affect any schemas of OCPP messages. The errata do contain changes to requirements or even new requirements,
but only in cases where a requirement contains an obvious error and would not or could not be implemented literally. New
requirements were only added when they were already implicitly there. These changes have been discussed in or were proposed by
the Technology Working Group of the Open Charge Alliance.

### Older version of errata documents

All errata up to and including Errata version 2025-11 have been included in the OCPP 2.1 Edition 1 specification, resulting into OCPP 2.1 Edition 2 released on 2025-12-03.